package tconstruct.library;

public interface ItemBlocklike {}
