package tconstruct.library.blocks;

public interface IDrawbridgeLogicBase{

	public boolean hasExtended();
	
}
