package tconstruct.library.util;

public interface IActiveLogic
{
    public boolean getActive ();

    public void setActive (boolean flag);
}